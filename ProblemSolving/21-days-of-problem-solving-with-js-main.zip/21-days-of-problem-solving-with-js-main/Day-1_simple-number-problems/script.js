// Brute force solution

const num = 10;

for(let i = 1; i <= num; i++) {
  // console.log(i ** 2n);
  // console.log(i * i);
  console.log(Math.pow(i, 2));
}